using JuMP
using Mosek
using MosekTools
model = Model(with_optimizer(Mosek.Optimizer))
@variable(model, P)
@variable(model, Q)
@variable(model, l)
@variable(model, S)
@variable(model, v)
@constraint(model, [l, v, P, Q] in RotatedSecondOrderCone())
@constraint(model, [0.5*S, S, P, Q] in RotatedSecondOrderCone())
@constraint(model, l<=16)
@constraint(model, v<=16)
@constraint(model, S<=2000)
@constraint(model, l>=15)
@constraint(model, v>=15)
for i=1:2
    for t=1:2
        if i==1 & t==1
            println("not this time")
        else
            println("work")
            println(i,t)
        end
    end
end


@objective(model, Min, P)
optimize!(model)
println(JuMP.objective_value(model))
println(JuMP.value(l))
println(JuMP.value(v))
println(JuMP.value(P))
